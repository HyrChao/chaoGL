#include "Debug.h"

Debug::Debug()
{
}


Debug::~Debug()
{
}
