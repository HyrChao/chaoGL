#include <Assets/AssetsManager.h>


vector<Texture> AssetsManager::textures_loaded;

