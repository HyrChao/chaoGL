#pragma once
#ifndef KEYBOARD_H
#define KEYBOARD_H
#include <GLFW/glfw3.h>

//class Keyboard
//{
//	static bool keyOnce[GLFW_KEY_LAST + 1];
//
//	static bool Pressed(int key)
//	{
//		glfwGetKey(window, GLFW_KEY_W)
//		keys[key] = action == GLFW_PRESS;
//	}
//}


#endif
