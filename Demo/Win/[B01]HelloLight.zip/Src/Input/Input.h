#pragma once
#ifndef INPUT_H
#define INPUT_H

#include<Application/Application.h>


class Input
{
public:
	Input();
	~Input();


private:


};


#endif
