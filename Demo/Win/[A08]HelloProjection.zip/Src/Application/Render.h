#pragma once
#ifndef RENDER_H
#define RENDER_H

#include<Application/Camera.h>
class Render
{
public:
	Render();
	~Render();

public:
	static Render* render;

private:


};
#endif
