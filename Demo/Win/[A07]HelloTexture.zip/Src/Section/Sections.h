#ifndef SECTIONS_H
#define SECTIONS_H

#include <Section\Hello.h>


class Sections
{
public:
	Sections();
	~Sections();
	void HelloTriangle();

private:

	Hello* hello;

};

#endif // !SECTIONS_H